// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional

//dev

export const firebaseConfig = {
  apiKey: "AIzaSyCL6pso2rjKwNY8AqZsCX7Y6cYujm-AkLk",
  authDomain: "granafacil-br.firebaseapp.com",
  projectId: "granafacil-br",
  storageBucket: "granafacil-br.appspot.com",
  messagingSenderId: "705435329440",
  appId: "1:705435329440:web:29646e136c604033a0bac5",
  measurementId: "G-G8986N56PW",
};
